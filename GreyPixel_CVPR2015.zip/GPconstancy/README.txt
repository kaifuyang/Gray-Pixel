INTRODUCTION
===================================================================================
This code is provided for research purpose only.
This code performs Illuminant Estimation Using Grey Pixels (GP) 
reported in:
 Kaifu Yang, Shaobing Gao, and Yongjie Li*. 
 Efficient Illuminant Estimation for Color Constancy Using Grey Pixels. CVPR,2015.

Please cite our paper if this code is used to motivate any publications.
===================================================================================
USAGE��

 run "example1.m" for an example of single-illuminant estimation.
 run "example2.m" for an example of multi-illuminant estimation.

Let us know if you have any questions at
Kaifu Yang <yangkf@uestc.edu.cn>