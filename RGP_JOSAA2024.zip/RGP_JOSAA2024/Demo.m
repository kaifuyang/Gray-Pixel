% clc; clear;
load('./NCCdataset/gt.mat'); % gts
img_path='./NCCdataset/img';   % images
mskpath = './NCCdataset/msk'; % masks

Nimg=513; 
Perf = zeros(Nimg,1);
Perf_rep = zeros(Nimg,1);

for i = 1:Nimg
    fprintf(2,'Processing image %d/%d...\n',i,Nimg);
    imname = [num2str(i) '.png'];
    img = double(imread([img_path '\' imname]));
    mask = logical(imread([msk_path '\' imname])); 
    
    img = imresize(img,0.5,'nearest');
    mask = imresize(mask,0.5,'nearest');

    Npixels = size(img,1)*size(img,2);
    numGPs= floor(0.1*Npixels/100);
    EvaLum = RGP(img,numGPs,mask);
    
    [arr,arr_rep]= angerr2(EvaLum,gt(i,:));
    Perf(i) = arr;
    Perf_rep(i) = arr_rep;
    
end

[mean,median,trimean,bst25,wst25] = evaluate(Perf);
[median,mean,trimean,bst25,wst25]

[mean,median,trimean,bst25,wst25] = evaluate(Perf_rep);
[median,mean,trimean,bst25,wst25]




