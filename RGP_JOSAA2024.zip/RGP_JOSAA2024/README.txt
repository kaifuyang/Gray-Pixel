INTRODUCTION
===================================================================================
This code is provided for research purpose only.
This code performs Nighttime Color Constancy Using Robust Gray Pixels (RGP) 
reported in:

C Cheng, KF Yang*, XM Wan, LLH Chen, YJ Li. 
Nighttime Color Constancy Using Robust Gray Pixels. JOSA A, 2024.

A new dataset (NCC dataset) that contains 513 nighttime images and corresponding ground-truth illuminants was collected.
Download: https://www.kaggle.com/datasets/yangkaifu/nighttime-color-constancy

Please cite our paper if this code is used to motivate any publications.
===================================================================================
USAGE��
1. Download the dataset to the path of NCCdataset.
2. Run "Demo.m" for an example of illuminant estimation.

Let us know if you have any questions at
Kai-Fu Yang <yangkf@uestc.edu.cn>