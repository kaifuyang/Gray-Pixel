function EvaLum = RGP(img,numGPs,mask)
% remove all saturated points
saturation_threshold = max(img(:))*0.95;
mask_im2 = mask + (dilation33(double(max(img,[],3)>=saturation_threshold)));   
mask_im2 = double(mask_im2==0);
mask = set_border(mask_im2,1,0);
mask = 1-mask;

window_size = 9; % N*N
[rr,cc,dd] = size(img);

img(img==0)=eps;
R=img(:,:,1); G=img(:,:,2); B=img(:,:,3);
R(R==0)=eps;  G(G==0)=eps;  B(B==0)=eps;


Lum = (R+G+B)/3;
M_lum = medfilt2(Lum,[window_size,window_size]);
M_lum = reshape(M_lum,[1,rr*cc]);
M_lum = repmat(M_lum,window_size.^2,1);

padding = floor(window_size/2);
Lum = padarray(Lum,[padding padding],'replicate');
Lum = im2col(Lum, [window_size window_size], 'sliding');

Groupidx = Lum-M_lum;
Groupidx(Groupidx>0)=1;
Groupidx(Groupidx<0)=0;

Mr = getIIMs(Groupidx,R,window_size,rr,cc);
Mg = getIIMs(Groupidx,G,window_size,rr,cc);
Mb = getIIMs(Groupidx,B,window_size,rr,cc);

data=[Mr(:),Mg(:),Mb(:)];
Ds= std(data,[],2);
Ds = Ds./(mean(data,2)+eps);

data1 = [R(:),G(:),B(:)];
Ds = Ds./(mean(data1,2)+eps);
Greyidx = reshape(Ds, [rr cc]);

Greyidx = Greyidx./(max(Greyidx(:))+eps);
Greyidx(Mr<eps & Mg<eps & Mb<eps)= max(Greyidx(:));

hh = fspecial('average',[7 7]);
Greyidx = imfilter(Greyidx,hh,'circular');
if ~isempty(mask)
    Greyidx(find(mask)) = max(Greyidx(:));
end

Greyidx(:,1:5) = max(Greyidx(:));
Greyidx(:,end-4:end) = max(Greyidx(:));
Greyidx(1:5,:) = max(Greyidx(:));
Greyidx(end-4:end,:) = max(Greyidx(:));
Greyidx(isnan(Greyidx)) = max(Greyidx(:));

tt=sort(Greyidx(:));
EvaLum = zeros(length(numGPs),3);

for kk = 1:length(numGPs)
    Gidx = zeros(size(Greyidx));
    Gidx(Greyidx<=tt(numGPs(kk))) = 1;
    RR = Gidx.*R;
    GG = Gidx.*G;
    BB = Gidx.*B;
    
    Rillu = sum(RR(:));
    Gillu = sum(GG(:));
    Billu = sum(BB(:));

    EvaLum(kk,:) =[Rillu Gillu Billu];
end


 