% angerr: Computes the angular error between two illuminants
%
% err = angerr(l1,l2)
%
%   l1,l2: Two illuminant color vectors  ===  l2 is gt
% RESULT
%   err:   Angular error in degrees
function [rec,rep]= angerr2(l1,l2)
  l1 = l1 / sqrt(sum(l1.^2));
  l2 = l2 / sqrt(sum(l2.^2));
  rec = acosd(sum(l1(:).*l2(:)));
  
  LL = l2./l1;
  rep = acosd( (LL*[1;1;1])/ (sqrt(3)*sqrt(sum(LL.^2))) );
  
  
  