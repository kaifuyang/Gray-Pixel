function [img_res] = getIIMs(groupidx,img,window_size,rr,cc)
padding = floor(window_size/2);
img = padarray(img,[padding padding],'replicate');
img = im2col(img, [window_size window_size], 'sliding');

uu=img.*groupidx; 
mhigh = sum(uu)./sum(groupidx==1);
clear uu;

uu=img.*(1-groupidx);
mlow = sum(uu)./sum(groupidx==0);
clear uu;

img_res = log(mhigh+eps)-log(mlow+eps);
img_res(isnan(img_res))=0;

img_res = col2im(img_res,[1 1],[rr cc],'sliding');
end
