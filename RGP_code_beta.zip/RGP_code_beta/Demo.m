% clc; clear;
load('B:/AdaVision/NightCC/Datasets/Dataset513/gt.mat'); % gts
main_path='B:/AdaVision/NightCC/Datasets/Dataset513/img';   % images
coordpath = 'B:/AdaVision/NightCC/Datasets/Dataset513/msk'; % masks

Nimg=513; 
Perf = zeros(Nimg,1);
Perf_rep = zeros(Nimg,1);

for i = 1:Nimg
    fprintf(2,'Processing image %d/%d...\n',i,Nimg);
    imname = [num2str(i) '.png'];
    img = double(imread([main_path '\' imname]));
    mask = logical(imread([coordpath '\' imname])); 
    
    img = imresize(img,0.5,'nearest');
    mask = imresize(mask,0.5,'nearest');

    Npixels = size(img,1)*size(img,2);
    numGPs= floor(0.1*Npixels/100);
    EvaLum = RGP(img,numGPs,mask);
    [arr,arr_rep]= angerr2(EvaLum,gt(i,:));
    Perf(i) = arr;
    Perf_rep(i) = arr_rep;
end

[men,median,trimean,bst25,wst25] = evaluate(Perf);
[median,men,trimean,bst25,wst25]




